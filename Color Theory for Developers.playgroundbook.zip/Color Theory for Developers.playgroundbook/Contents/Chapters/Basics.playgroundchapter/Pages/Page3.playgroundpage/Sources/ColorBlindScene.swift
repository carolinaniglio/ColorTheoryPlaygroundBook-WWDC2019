// // by Carolina Niglio for WWDC 2019
// Page 3 - ColorBlindScene Class

import PlaygroundSupport
import SpriteKit

public class ColorBlindScene: SKScene {
    
    //Declaring Variables
    var theAppIcon: String?
    var node = SKSpriteNode(texture: SKTexture(imageNamed: "black&white"))
    var nodeTouched = SKSpriteNode(texture: SKTexture(imageNamed: "black&white"))
    var nodeTexture = String()
    var targetNode = SKSpriteNode()
    let instruction = SKLabelNode(text: "Press and hold")
    var isTouching = Bool()
    let backgroundNode = SKSpriteNode(color: #colorLiteral(red: 0.1176470588, green: 0.1176470588, blue: 0.1176470588, alpha: 1), size: CGSize(width: 1024, height: 768))

    //sceneDidLoad
    public override func sceneDidLoad() {
    addChild(backgroundNode)
    backgroundNode.isUserInteractionEnabled = false
        
    node.position = CGPoint(x: 0, y: -30)
    node.xScale = 0.3
    node.yScale = 0.3
    addChild(node)

    nodeTouched.position = CGPoint(x: 0, y: -30)
    nodeTouched.xScale = 0.3
    nodeTouched.yScale = 0.3
    nodeTouched.alpha = 0
    addChild(nodeTouched)
        
    instruction.position = CGPoint(x: 0, y: 170)
    instruction.fontName = "Avenir Light"
    instruction.fontSize = 21
    instruction.color = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    instruction.alpha = 0
    addChild(instruction)
    }
    
    //Taking the value from LiveView
    public override func update(_ currentTime: TimeInterval) {
    if let keyValue = PlaygroundKeyValueStore.current["appIcon"],
    case .string(let appIcon) = keyValue {
         theAppIcon = appIcon
    
    instruction.alpha = 1
        
     switch theAppIcon {
        case "spotify":
            node.texture = SKTexture(imageNamed: "Spotify")
        case "chrome":
            node.texture = SKTexture(imageNamed: "GoogleChrome")
        case "forest":
            node.texture = SKTexture(imageNamed: "Forest")
        case "infinity":
            node.texture = SKTexture(imageNamed: "Infinity")
        default:
            break
                }
            }
        }

    //When touch begin change image to the colorblind version
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches {
            isTouching = true
            let touch = touches.first as UITouch!
            let touchLocation = touch?.location(in: self)
            targetNode = atPoint(touchLocation!) as! SKSpriteNode
            nodeTexture = targetNode.texture?.description ?? "nil"
            
            func textureName() -> String {
                var textDesc = String()
                if targetNode.texture?.description != nil {
                    textDesc = (targetNode.texture?.description)!
                    let indexStart = textDesc.index(textDesc.startIndex, offsetBy: 13)
                    let indexEnd = textDesc.index(textDesc.endIndex, offsetBy: -15)
                    let textName = textDesc[indexStart..<indexEnd]
                    return String(textName)
                } else {
                    return "nil"
                }
            }
            
            switch textureName() {
                
            case "Spotify":
                node.removeFromParent()
                nodeTouched.alpha = 1
                nodeTouched.texture = SKTexture(imageNamed: "SpotifyP")
                
            case "GoogleChrome":
                node.removeFromParent()
                nodeTouched.alpha = 1
                nodeTouched.texture = SKTexture(imageNamed: "GoogleChromeP")
                
            case "Forest":
                node.removeFromParent()
                nodeTouched.alpha = 1
                nodeTouched.texture = SKTexture(imageNamed: "ForestP")
                
            case "Infinity":
                node.removeFromParent()
                nodeTouched.alpha = 1
                nodeTouched.texture = SKTexture(imageNamed: "InfinityP")
                
            default:
                break
                
            }
        }
    }
    
    //When touche ends change image to the original version
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = false
        for touch: AnyObject in touches {
            isTouching = true
            let touch = touches.first as UITouch!
            let touchLocation = touch?.location(in: self)
            targetNode = atPoint(touchLocation!) as! SKSpriteNode
            nodeTexture = targetNode.texture?.description ?? "nil"
            
            func textureName() -> String {
                var textDesc = String()
                if targetNode.texture?.description != nil {
                    textDesc = (targetNode.texture?.description)!
                    let indexStart = textDesc.index(textDesc.startIndex, offsetBy: 13)
                    let indexEnd = textDesc.index(textDesc.endIndex, offsetBy: -15)
                    let textName = textDesc[indexStart..<indexEnd]
                    return String(textName)
                } else {
                    return "nil"
                }
            }
            
            switch textureName() {
                
            case "SpotifyP":
                nodeTouched.alpha = 0
                addChild(node)
                
            case "GoogleChromeP":
                nodeTouched.alpha = 0
                addChild(node)
                
            case "ForestP":
                nodeTouched.alpha = 0
                addChild(node)
                
            case "InfinityP":
                nodeTouched.alpha = 0
                addChild(node)
                
            default:
                break
                
            }
        }
    }
}
