/*:

 # 👁 Let's see eye to eye
 
_“So, is it that so easy?”_ the dev says.
 
_“Yeah, well... but wait, there’s one more thing!
Do you know anything about color blindness?”_

**Color blindness**, also known as color vision deficiency, is the decreased ability to see color or differences in color.

Here’s some tips to make design accessible and significant also for colorblind people.
    
 ### Contrast.
 Every text must have enough contrast with the background, so check if the two colors ratio is at least 4.5:1 for normal text and 3:1 for large text and graphics and user interface components.
 
  ![contrastRatio](contrastRatio.png)

 ### Use different shades of the same colors instead of more colors together.
 This ensure that the interface components convey affordance thanks to contrast, but there are no worries about combining colors.
 
  ![monochromatic](monochromatic.png)
    
 ### Use texture instead of colors.
 Make graphic elements understandable through different textures and patterns and not colors.
 
  ![texture](texture.png)
 
 ### Do not use some combinations.
 These combinations are very harsh to look at for colorblinds: Red and Green, Black and Green, Light Green & Yellow, Green and Brown, Blue and Purple, Blue and Green.
 
 Let's see some famous app icons that were not designed for colorblinds since they use these mixes of colors.
 
* Experiment:
_Choose from the hints which icon app you would like to try_
 */

//#-hidden-code
import PlaygroundSupport

public enum AppIcon: String {
  case spotify
  case chrome
  case forest
  case infinity
}

var selectedAppIcon: AppIcon

//#-end-hidden-code

selectedAppIcon =  /*#-editable-code*/.<#T##App Icon##AppIcon#>/*#-end-editable-code*/

//#-hidden-code
var rawSelectedAppIcon = selectedAppIcon.rawValue
PlaygroundKeyValueStore.current["appIcon"] = .string(rawSelectedAppIcon)
//#-end-hidden-code

/*:
 
_Run code_
 
_Press and hold to discover how colorblinds actually see them._
 
 * Important:
 This is a simulation that is not scientifically accurate. The colors you're seeing are likely the colors people with protanopia (insensitivity to red) e deuteranopia (insensitivity to green) see.
 
 ---
 
 Go to [next chapter](@next) for an advanced game.
 
 */

