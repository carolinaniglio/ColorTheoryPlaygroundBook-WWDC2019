// by Carolina Niglio for WWDC 2019
// Page 2 - Color Wheel Scene Class

import PlaygroundSupport
import SpriteKit

public class ColorWheelScene: SKScene {
    
    // Declaring Variables
    var targetNode = SKSpriteNode()
    var targetNodeName = String()
    var firstTouched = SKSpriteNode()
    var secondTouched = SKSpriteNode()
    var thirdTouched = SKSpriteNode()
    var firstTouchedName: String?
    var secondTouchedName: String?
    var thirdTouchedName: String?
    var index = 0
    var discovered = false
    var firstTouchedIndex = 0
    var secondTouchedIndex = 0
    var thirdTouchedIndex = 0
    var fourtTouched = SKSpriteNode()
    var total1 = Int()
    var total2 = Int()
    var total3 = Int()
    let label = SKLabelNode(text: "Try combinations")
    let onLabel = SKSpriteNode(imageNamed: "label")
    var text = ""
    let tryAgainButton = SKSpriteNode(imageNamed: "tryAgain")
    let firstColor = SKSpriteNode(texture: SKTexture(imageNamed: "pantone"))
    let secondColor = SKSpriteNode(texture: SKTexture(imageNamed: "pantone"))
    let thirdColor = SKSpriteNode(texture: SKTexture(imageNamed: "pantone"))
    var texture = SKTexture()
    
    //Actions
    let fadeOut = SKAction.fadeAlpha(to: 0, duration: 0.3)
    let fadeIn = SKAction.fadeAlpha(to: 1, duration: 0.3)
    let moveTo1 = SKAction.move(to: CGPoint(x: -40, y: 235), duration: 0.3)
    let moveTo2 = SKAction.move(to: CGPoint(x: 40, y: 235), duration: 0.3)
    let moveBack1 = SKAction.move(to: CGPoint(x: -80, y: 235), duration: 0.3)
    let moveBack2 = SKAction.move(to: CGPoint(x: 0, y: 235), duration: 0.3)
    
    // sceneDidLoad
    public override func sceneDidLoad() {
        label.position = CGPoint(x: 0, y: -260)
        label.fontColor = SKColor.white
        label.fontName = "Avenir Light"
        label.fontSize = 32.0
        addChild(label)
        
        onLabel.position = CGPoint(x: 0, y: -270)
        onLabel.isUserInteractionEnabled = false
        addChild(onLabel)
        
        tryAgainButton.position = CGPoint(x: 0, y: 0)
        tryAgainButton.xScale = 0.1
        tryAgainButton.yScale = 0.1
        addChild(tryAgainButton)
        tryAgainButton.alpha = 0
        
        firstColor.position = CGPoint(x: -80, y: 235)
        firstColor.xScale = 0.1
        firstColor.yScale = 0.1
        addChild(firstColor)
        secondColor.position = CGPoint(x: 0, y: 235)
        secondColor.xScale = 0.1
        secondColor.yScale = 0.1
        addChild(secondColor)
        thirdColor.position = CGPoint(x: 80, y: 235)
        thirdColor.xScale = 0.1
        thirdColor.yScale = 0.1
        addChild(thirdColor)
        
    }
    
    //Handling touches with touchesBegan
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch: AnyObject in touches {
            let touch = touches.first as UITouch!
            let touchLocation = touch?.location(in: self)
            targetNode = atPoint(touchLocation!) as! SKSpriteNode
            targetNodeName = targetNode.name ?? "nil"
            
            if targetNodeName == "background" {
                label.text = "Try again"
            }
            
            if targetNode == tryAgainButton {
                inizialize()
            }
            
            if discovered == false {
                
                switch targetNodeName {
                    
                case "yellowNode":
                    
                    targetNodeName = "yellowNode"
                    index = 1
                    print(index)
                    texture = SKTexture(imageNamed: "yellowRect")
                    
                case "yellowOrangeNode":
                    targetNodeName = "yellowOrangeNode"
                    index = 2
                    print(index)
                    texture = SKTexture(imageNamed: "yellowOrangeRect")
                    
                case "orangeNode":
                    targetNodeName = "orangeNode"
                    index = 3
                    print(index)
                    texture = SKTexture(imageNamed: "orangeRect")
                    
                case "redOrangeNode":
                    targetNodeName = "redOrangeNode"
                    index = 4
                    print(index)
                    texture = SKTexture(imageNamed: "redOrangeRect")
                    
                case "redNode":
                    targetNodeName = "redNode"
                    index = 5
                    print(index)
                    texture = SKTexture(imageNamed: "redRect")
                    
                case "redVioletNode":
                    targetNodeName = "redVioletNode"
                    index = 6
                    print(index)
                    texture = SKTexture(imageNamed: "redVioletRect")
                    
                case "violetNode":
                    targetNodeName = "violetNode"
                    index = 7
                    print(index)
                    texture = SKTexture(imageNamed: "violetRect")
                    
                case "blueVioletNode":
                    targetNodeName = "blueVioletNode"
                    index = 8
                    print(index)
                    texture = SKTexture(imageNamed: "blueVioletRect")
                    
                case "blueNode":
                    targetNodeName = "blueNode"
                    index = 9
                    print(index)
                    texture = SKTexture(imageNamed: "blueRect")
                    
                case "blueGreenNode":
                    targetNodeName = "blueGreenNode"
                    index = 10
                    print(index)
                    texture = SKTexture(imageNamed: "blueGreenRect")
                    
                case "greenNode":
                    targetNodeName = "greenNode"
                    index = 11
                    print(index)
                    texture = SKTexture(imageNamed: "greenRect")
                    
                case "yellowGreenNode":
                    targetNodeName = "yellowGreenNode"
                    index = 12
                    print(index)
                    texture = SKTexture(imageNamed: "yellowGreenRect")
                    
                default:
                    break
                }
            }
        }
        confront()
    }
    
    //Saving touches in 3 variables and confronting if not nil
    func confront() {
        if firstTouchedName == nil && firstTouchedIndex == 0 && targetNodeName != "background" && targetNode != tryAgainButton {
            firstTouched = targetNode
            firstTouchedName = targetNodeName
            firstTouchedIndex = index
            firstColor.texture = texture
            
        } else if firstTouchedName != nil && firstTouchedIndex != 0 && secondTouchedName == nil && secondTouchedIndex == 0 && targetNodeName != "background" && targetNode != tryAgainButton {
            secondTouched = targetNode
            secondTouchedName = targetNodeName
            secondTouchedIndex = index
            secondColor.texture = texture
            confrontComplementary()
            
        } else if firstTouchedName != nil && firstTouchedIndex != 0 && secondTouchedName != nil && secondTouchedIndex != 0 && thirdTouchedName == nil && thirdTouchedIndex == 0 && targetNodeName != "background" && targetNode != tryAgainButton {
            thirdTouched = targetNode
            thirdTouchedName = targetNodeName
            thirdTouchedIndex = index
            thirdColor.texture = texture
            confrontThree()
        }
    }
    
    func confrontComplementary(){
        total1 = (secondTouchedIndex) - (firstTouchedIndex)
        if total1 == 6 || total1 == -6 {
            print("complementary")
            text = "Complementary"
            let appearing = SKAction.sequence([fadeOut, changeText(), fadeIn])
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = false
            firstColor.run(moveTo1)
            secondColor.run(moveTo2)
            thirdColor.alpha = 0
        }
    }
    
    func confrontThree() {
        total2 = (thirdTouchedIndex) - (secondTouchedIndex)
        total3 = (thirdTouchedIndex) - (firstTouchedIndex)
        thirdColor.run(fadeIn)
        firstColor.run(moveBack1)
        secondColor.run(moveBack2)
        let appearing = SKAction.sequence([fadeOut, changeText(), fadeIn])
        
        if total3 == 2 || total3 == -2 {
            text = "Analogous"
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = true
        } else if total2 == 2 || total2 == -2 || total2 == 10 || total2 == -10 || total2 == 5 || total2 == -5 || total2 == 7 || total2 == -7 {
            text = "Split"
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = true
        } else if total2 == 4 || total2 == -4 || total2 == 8 || total2 == -8 {
            text = "Triadic"
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = true
        } else if total3 == 0 {
            text = "Monochromatic"
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = true
        } else {
            text = "Try again"
            label.run(appearing)
            tryAgainButton.run(appearing)
            discovered = true
        }
    }
    
    func inizialize() {
        discovered = false
        tryAgainButton.alpha = 0
        label.text = "Try combinations"
        firstTouchedName = nil
        secondTouchedName = nil
        thirdTouchedName = nil
        firstTouchedIndex = 0
        secondTouchedIndex = 0
        thirdTouchedIndex = 0
        firstColor.texture = SKTexture(imageNamed: "pantone")
        secondColor.texture = SKTexture(imageNamed: "pantone")
        thirdColor.texture = SKTexture(imageNamed: "pantone")
        firstColor.run(moveBack1)
        secondColor.run(moveBack2)
        thirdColor.run(fadeIn)
    }
    
    func changeText() -> SKAction { return SKAction.run {
        self.label.text = self.text
        }
    }
}
