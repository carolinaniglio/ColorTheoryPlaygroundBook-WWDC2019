// by Carolina Niglio for WWDC 2019
//Page 2 - Live View

import PlaygroundSupport
import SpriteKit

// Load the SKScene from 'ColowWheelScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 1024, height: 768))
if let scene = ColorWheelScene(fileNamed: "ColorWheelScene") {
    scene.scaleMode = .aspectFill
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
