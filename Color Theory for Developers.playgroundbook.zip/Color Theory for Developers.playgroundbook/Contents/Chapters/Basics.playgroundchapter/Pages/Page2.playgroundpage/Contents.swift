/*:
 # 🎨 How to combine colors?
 
 _“How could you match a yellow font with a red background?”_ sayd the designer.
 
 To combine colors, artists and designers often use a tool called color wheel, that you can see on the live view./
 Using this wheel can help designers and coders deal with the _difficult choice_ of which colors to put in their app. So __read carefully before using__.
 
 ### Analogous Color Palette
 To make this combination, you pick up one color and then colors adjacent to it. This creates a palette of harmonious and easy to look at colors.
 
 ![analogous](analogous.png)
 
 ### Complementary Color Palette
 Pick up a color and the the opposite one on the wheel: this combinations is attention grabbing so use it for instance for the icon of your app and not in every screen.
 
 ![complementary](complementary.png)
 
 ### Split Color Palette
 Choose a color and then pick up two colors that are adjacent to the opposite color: that's how you made a split color palette. Always attention grabbing, but also very easy to look at.
 
 ![split](split.png)
 
 ### Triadic Color Palette
 In this case you pick up a color and draw an equilateral triangle, like in the image. This combination gives a well-balanced feel.
 
 ![triadic](triadic.png)
 
 * Experiment:
 Try to combine and see the result!
 
 ---
 
 [One more thing...](Design%20for%20colorblind)
