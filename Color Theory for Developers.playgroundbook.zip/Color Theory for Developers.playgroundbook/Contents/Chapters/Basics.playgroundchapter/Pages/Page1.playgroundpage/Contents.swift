/*:
 
 # Once upon a time...
 
 Every day a developer 👨🏽‍💻 wakes up in the jungle, where, hidden beyond a tree 🌳 there’s a designer. 👩🏻‍🎨 There is no predator or prey among them, no hate, but a costant misuderstanding. ⁉️
 
 The developer thinks the sky is *blue* 🔵 but the designer says:
 
 _“What the heck? During the day the sky takes so many colors that I can’t even count them”_ 🌅🌄🌌
 
 _“I will never understand you...”_ says the developer.
 
 __Why do developers need this book?__

 Colors always mean something, even if you don’t notice it... Using them properly is a kind of art.
 
 Let's start with a non-color: **white** is the lightest colors and it contains all the colors of the visible wavelenghts of light. It is opposed to **black**, which is the absence of colors.
 
 🌹 **Red** means Love, Energy, and Intensity.
 
 🍊 **Orange** stays for Fresh, Youthful, Creative & Adventurous.
 
 🐤 **Yellow** conveys Joy, Attention, Intellect.
 
 ☘️ **Green** is associated with Freshness, Safety, and Growth.
 
 🦋 **Blue**: Stability. Trust. Serenity.
 
 🔮 **Purple** stands for Royalty, Wealth, Feminity.

 * Experiment:
 How to use the symbolism of colors in an app? Find out tapping the colors you see in the panel.
 
 ---
 
Go to [next page](Combining%20colors) to find out how to use these colors together.
