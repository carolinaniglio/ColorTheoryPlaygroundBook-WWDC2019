//by Carolina Niglio for WWDC 2019
//Page 1 - CirclesScene Class

import PlaygroundSupport
import SpriteKit

public class CirclesScene: SKScene {
    
    //Declaring variables
    var targetNode = SKSpriteNode()
    var targetNodeName = String()
    var BKG: UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    var firstTouched = SKSpriteNode()
    
    //All nodes
    let redNode = SKSpriteNode(imageNamed: "redCircle")
    let yellowNode = SKSpriteNode(imageNamed: "yellowCircle")
    let orangeNode = SKSpriteNode(imageNamed: "orangeCircle")
    let greenNode = SKSpriteNode(imageNamed: "greenCircle")
    let blueNode = SKSpriteNode(imageNamed: "blueCircle")
    let purpleNode = SKSpriteNode(imageNamed: "purpleCircle")
    let whiteNode = SKSpriteNode(imageNamed: "whiteCircle")
    let floorNode = SKSpriteNode(color: UIColor.black, size: CGSize(width: 1024, height: 100))
    let backgroundNode = SKSpriteNode(color: #colorLiteral(red: 0.1176327839, green: 0.1176561788, blue: 0.117627643, alpha: 1), size: CGSize(width: 1024, height: 768))
    let tryAgainNode = SKSpriteNode(imageNamed: "tryAgain")
    
    let redPosition = CGPoint(x: 0, y: 160)
    let orangePosition = CGPoint(x: 160, y: 80)
    let yellowPosition = CGPoint(x: 160, y: -80)
    let greenPosition = CGPoint(x: 0, y: -160)
    var bluePosition = CGPoint(x: -160, y: -80)
    var purplePosition = CGPoint(x: -160, y: 80)
    
    var moodLabel = SKLabelNode(fontNamed: "Avenir Light")
    let label = SKLabelNode(text: "")
    
    //Actions
    let moveDown = SKAction.move(to: CGPoint(x: 0, y: -500), duration: 0.5)
    let wait = SKAction.wait(forDuration: 2)
    let scale = SKAction.scale(by: 100, duration: 1)
    let scaleBack = SKAction.scale(to: 0, duration: 1)
    let fadeOut = SKAction.fadeOut(withDuration: 2)
    let colorize = SKAction.colorize(with: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), colorBlendFactor: 1.0, duration: 1)
    let waitMore = SKAction.wait(forDuration: 2)
    
    //sceneDidLoad
    public override func sceneDidLoad() {
        entryCircles()
        backgroundNode.color = #colorLiteral(red: 0.1176327839, green: 0.1176561788, blue: 0.117627643, alpha: 1)
        whiteNode.xScale = 0.15
        whiteNode.yScale = 0.15
        whiteNode.position = CGPoint(x: 0, y: 0)
        whiteNode.physicsBody = nil
        let whiteAction = SKAction.sequence([fadeOut])
        whiteNode.run(whiteAction)
        addChild(whiteNode)
        label.position = CGPoint(x: 0, y: 0)
        label.fontName = "Avenir Light"
        label.horizontalAlignmentMode = .center
        label.verticalAlignmentMode = .center
        label.fontSize = 21.0
        label.numberOfLines = 2
        label.preferredMaxLayoutWidth = 200
        label.alpha = 0
        let delay = SKAction.wait(forDuration: 2)
        let fadeIn = SKAction.fadeAlpha(to: 1, duration: 1)
        let appearing = SKAction.sequence([delay, fadeIn])
        let appearing2 = SKAction.sequence([delay, fadeIn, userInteractionEnable()])
        addChild(label)
        self.label.run(appearing2)
    }
    
    //Handling touches with touchesBegan
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //Sprite actions when pressed
        let fallAction = SKAction.sequence([userInteractionDisable(), addPhysicBody(), applyGravity(), wait, scale, changeBKG(), scaleBack, userInteractionEnable()])
        let moveFloor = SKAction.sequence([wait, moveDown])
        
        for touch: AnyObject in touches {
            let touch = touches.first as UITouch!
            let touchLocation = touch?.location(in: self)
            targetNode = atPoint(touchLocation!) as! SKSpriteNode
            
            switch targetNode {
                
            case backgroundNode:
                
                if firstTouched == nil {
                    label.text = "Try again"
                } else if firstTouched != nil {
                    removeAllChildren()
                    removeAllActions()
                    entryCircles()
                    BKG = #colorLiteral(red: 0.1176327839, green: 0.1176561788, blue: 0.117627643, alpha: 1)
                    backgroundNode.color = BKG
                }
                
            case redNode:
                targetNode.run(fallAction)
                yellowNode.removeFromParent()
                orangeNode.removeFromParent()
                greenNode.removeFromParent()
                blueNode.removeFromParent()
                purpleNode.removeFromParent()
                label.removeFromParent()
                firstTouched = redNode
                moodLabel.text = "Red has such powerful meanings. Think about a brand or an app that use it, and you may notice that there are a few out there, and with a strong identity, for istance Coca Cola. Use it carefully, and only if it says something about what you do."
                addLabel()
                BKG = #colorLiteral(red: 1, green: 0.2705882353, blue: 0.2274509804, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            case orangeNode:
                targetNode.run(fallAction)
                redNode.removeFromParent()
                yellowNode.removeFromParent()
                greenNode.removeFromParent()
                blueNode.removeFromParent()
                purpleNode.removeFromParent()
                label.removeFromParent()
                firstTouched = orangeNode
                moodLabel.text = "Blending the warmth of red and the optimism of yellow, orange communicates activity and energy. Brands that use this color want to say that their product is specifically made for young people."
                addLabel()
                BKG = #colorLiteral(red: 1, green: 0.6235294118, blue: 0.03921568627, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            case yellowNode:
                targetNode.run(fallAction)
                redNode.removeFromParent()
                orangeNode.removeFromParent()
                greenNode.removeFromParent()
                blueNode.removeFromParent()
                purpleNode.removeFromParent()
                label.removeFromParent()
                firstTouched = yellowNode
                moodLabel.text = "Yellow gives a sens of cheerfulness, friendliness, joy and energy. But, the downfall is that can look cheap in some shades. Use it only if your app does somenthing very intellectually appealing."
                addLabel()
                BKG = #colorLiteral(red: 1, green: 0.8392156863, blue: 0.03921568627, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            case greenNode:
                targetNode.run(fallAction)
                redNode.removeFromParent()
                orangeNode.removeFromParent()
                yellowNode.removeFromParent()
                blueNode.removeFromParent()
                purpleNode.removeFromParent()
                label.removeFromParent()
                firstTouched = greenNode
                moodLabel.text = "Green has two very different meaning in light shades it conveys environmental, sustainable, organic, natural sense of the word, while darker greens represent prestige, wealth and abundance."
                addLabel()
                BKG = #colorLiteral(red: 0.1960784314, green: 0.8431372549, blue: 0.2941176471, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            case blueNode:
                targetNode.run(fallAction)
                redNode.removeFromParent()
                orangeNode.removeFromParent()
                yellowNode.removeFromParent()
                greenNode.removeFromParent()
                purpleNode.removeFromParent()
                label.removeFromParent()
                firstTouched = blueNode
                moodLabel.text = "Blue is the most universally preferred color, and therefore many app use it as principal color because of an expressive power. It is used to convey reliability and trustworthiness, but it is also associeted with the feeling of sadness. Use wisely."
                addLabel()
                BKG = #colorLiteral(red: 0.03921568627, green: 0.5176470588, blue: 1, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            case purpleNode:
                targetNode.run(fallAction)
                redNode.removeFromParent()
                orangeNode.removeFromParent()
                yellowNode.removeFromParent()
                greenNode.removeFromParent()
                blueNode.removeFromParent()
                label.removeFromParent()
                firstTouched = purpleNode
                moodLabel.text = "Even if it means wealth, not lot brand use purple. It is surely preferred when making products for women, but usually it conveys a feeling of elegance. So, if the color fits the app's aim, then you should totally use it becuse there is a chance you will stand out."
                addLabel()
                BKG = #colorLiteral(red: 0.7490196078, green: 0.3529411765, blue: 0.9490196078, alpha: 1)
                floorNode.run(moveFloor)
                tryAgain()
                break
                
            default:
                break
            }
        }
    }
    
    //Initial adding nodes
    func entryCircles() {
        
        addChild(backgroundNode)
        
        var moveTo1 = SKAction.move(to: redPosition, duration: 1)
        var moveCircles = SKAction.sequence([moveTo1, wait, addPhysicBody()])
        redNode.xScale = 0.15
        redNode.yScale = 0.15
        redNode.physicsBody = nil
        redNode.position = CGPoint(x: 0, y: 0)
        addChild(redNode)
        redNode.run(moveCircles)
        
        var moveTo2 = SKAction.move(to: orangePosition, duration: 1)
        moveCircles = SKAction.sequence([moveTo2, wait, addPhysicBody()])
        orangeNode.xScale = 0.15
        orangeNode.yScale = 0.15
        orangeNode.position = CGPoint(x: 0, y: 0)
        orangeNode.physicsBody = nil
        addChild(orangeNode)
        orangeNode.run(moveCircles)
        
        var moveTo3 = SKAction.move(to: yellowPosition, duration: 1)
        moveCircles = SKAction.sequence([moveTo3, wait, addPhysicBody()])
        yellowNode.xScale = 0.15
        yellowNode.yScale = 0.15
        yellowNode.position = CGPoint(x: 0, y: 0)
        yellowNode.physicsBody = nil
        addChild(yellowNode)
        yellowNode.run(moveCircles)
        
        var moveTo4 = SKAction.move(to: greenPosition, duration: 1)
        moveCircles = SKAction.sequence([moveTo4, wait, addPhysicBody()])
        greenNode.xScale = 0.15
        greenNode.yScale = 0.15
        greenNode.position = CGPoint(x: 0, y: 0)
        greenNode.physicsBody = nil
        addChild(greenNode)
        greenNode.run(moveCircles)
        
        var moveTo5 = SKAction.move(to: bluePosition, duration: 1)
        moveCircles = SKAction.sequence([moveTo5, wait, addPhysicBody()])
        blueNode.xScale = 0.15
        blueNode.yScale = 0.15
        blueNode.position = CGPoint(x: 0, y: 0)
        blueNode.physicsBody = nil
        addChild(blueNode)
        blueNode.run(moveCircles)
        
        var moveTo6 = SKAction.move(to: purplePosition, duration: 1)
        moveCircles = SKAction.sequence([moveTo6, wait, addPhysicBody()])
        purpleNode.xScale = 0.15
        purpleNode.yScale = 0.15
        purpleNode.position = CGPoint(x: 0, y: 0)
        purpleNode.physicsBody = nil
        addChild(purpleNode)
        purpleNode.run(moveCircles)
        
        
        floorNode.position = CGPoint(x: 0, y: -435)
        floorNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 1024, height: 100))
        floorNode.physicsBody?.affectedByGravity = false
        floorNode.physicsBody?.pinned = true
        floorNode.physicsBody?.isDynamic = false
        addChild(floorNode)
    }
    
    func addPhysicBody() -> SKAction { return SKAction.run {
        self.redNode.physicsBody = SKPhysicsBody(circleOfRadius: self.redNode.size.width / 2)
        self.redNode.physicsBody?.affectedByGravity = false
        self.orangeNode.physicsBody = SKPhysicsBody(circleOfRadius: self.orangeNode.size.width / 2)
        self.orangeNode.physicsBody?.affectedByGravity = false
        self.yellowNode.physicsBody = SKPhysicsBody(circleOfRadius: self.orangeNode.size.width / 2)
        self.yellowNode.physicsBody?.affectedByGravity = false
        self.greenNode.physicsBody = SKPhysicsBody(circleOfRadius: self.greenNode.size.width / 2)
        self.greenNode.physicsBody?.affectedByGravity = false
        self.blueNode.physicsBody = SKPhysicsBody(circleOfRadius: self.blueNode.size.width / 2)
        self.blueNode.physicsBody?.affectedByGravity = false
        self.purpleNode.physicsBody = SKPhysicsBody(circleOfRadius: self.purpleNode.size.width / 2)
        self.purpleNode.physicsBody?.affectedByGravity = false
        }
    }
    
    
    func applyGravity() -> SKAction { return SKAction.run {
        self.targetNode.physicsBody?.affectedByGravity = true
        }
    }
    
    func remove() -> SKAction { return SKAction.run {
        self.targetNode.removeFromParent()
        }
    }
    
    func changeBKG() -> SKAction { return SKAction.run {
        self.backgroundNode.color = self.BKG
        }
    }
    
    func userInteractionEnable() -> SKAction { return SKAction.run  {
        self.scene?.isUserInteractionEnabled = true
        }
    }
    
    func userInteractionDisable() -> SKAction { return SKAction.run  {
        self.scene?.isUserInteractionEnabled = false
        }
    }
    
    //Adding the description label
    func addLabel() {
        addChild(moodLabel)
        moodLabel.position = CGPoint(x: 0, y: 0)
        moodLabel.fontSize = 20.0
        moodLabel.alpha = 0
        moodLabel.numberOfLines = 4
        moodLabel.preferredMaxLayoutWidth = 500
        moodLabel.horizontalAlignmentMode = .center
        moodLabel.verticalAlignmentMode = .center
        let delay = SKAction.wait(forDuration: 2.5)
        let fadeIn = SKAction.fadeAlpha(to: 1, duration: 0.7)
        let appearing = SKAction.sequence([delay, fadeIn])
        self.moodLabel.run(appearing)
    }
    
    //Adding try again button
    func tryAgain() {
        tryAgainNode.alpha = 0
        tryAgainNode.xScale = 0.06
        tryAgainNode.yScale = 0.06
        tryAgainNode.position = CGPoint(x: 170, y: -220)
        let delay = SKAction.wait(forDuration: 2.5)
        let fadeIn = SKAction.fadeAlpha(to: 1, duration: 1)
        let appearing = SKAction.sequence([delay, fadeIn])
        addChild(tryAgainNode)
        self.tryAgainNode.run(appearing)
        
        label.text = "Tap anywhere to try again"
        label.alpha = 0
        label.position = CGPoint(x: 50, y: -220)
        label.fontName = "Avenir Light"
        label.fontSize = 16.0
        addChild(label)
        self.label.run(appearing)
    }
}
