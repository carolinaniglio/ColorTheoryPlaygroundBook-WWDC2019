/*:
 
 # Credits
 
 This Playground Book was entirely built by _Carolina Niglio_.
 
 __All assets, animations and code are original.__
 
 ---
 
 The only contents taken from free resources on the internet are the famous app icons in the third page, ‘Design for colorblind’, then modified to make them look like the colors people with protanopia (insensitivity) e deuteranopia (insensitivity to green) see.
 
 _Their use has no commercial aim but they are displayed only for an educational purpose._
 
 ---
 
 __Thanks for reading!__ 🌈
