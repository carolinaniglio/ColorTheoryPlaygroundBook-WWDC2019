/*:

 # ❤️💚💙
 ### How are colors made?
 
 The colors people are used to see are the ones displayed on their electronical devices.
 
 This kind of colors are named **RGB**. What does that mean? RGB stands for Red, Blue and Green and it is an __additive color model__.
 In this model the three primary colors' lights are addedd together in various way to reproduce a broad array of colors.
 
 ![RGBModel](RGB.png)
 
 This model is essentialy opposite to the subtractive color model, like [CMYK](glossary://CMYK).
 
 An RGB color is described by indicating how much of red, green and blue is included and every componenet can vary from **0** to the maximum, which is **255** in computers. This means that we can generate _16.777.216_ different colors.
 
 Zero intensity for each component gives the __darkest color__ (no light, considered the black), and full intensity of each gives a **white**. When the intensities for all the components are the same, the result is a shade of gray, darker or lighter depending on the intensity.
 
 When one of the components has the strongest intensity, the color is a [hue](glossary://Hue) near this __primary color__ (reddish, greenish or bluish), and when two components have the same strongest intensity, then the color is a hue of a __secondary color__ (a shade of cyan, magenta or yellow).
 
 * Experiment:
 Now try on your own to make a color!
 
 __Choose a basic color to be shown on the left__
 
 */
 //#-hidden-code
 import PlaygroundSupport
 import UIKit
 
 var red: Double
 var green: Double
 var blue: Double
 var alpha: Double
 
 enum UIColors: String {
 case red
 case orange
 case yellow
 case green
 case cyan
 case blue
 case magenta
 case purple
 case gray
 case brown
 case black
 case white
 }
 
 var selectedUIColor: UIColors = .black
 //#-end-hidden-code
selectedUIColor =  /*#-editable-code*/.<#T##Color to confront##UIColors#>/*#-end-editable-code*/
//#-hidden-code
var rawSelectedUIColor = selectedUIColor.rawValue
PlaygroundKeyValueStore.current["color"] = .string(rawSelectedUIColor)
//#-end-hidden-code
/*:
 __Change the RGB values of the one on the right__
 */
red = /*#-editable-code*/0/*#-end-editable-code*/
green = /*#-editable-code*/0/*#-end-editable-code*/
blue = /*#-editable-code*/0/*#-end-editable-code*/
//#-hidden-code
PlaygroundKeyValueStore.current["r"] = .floatingPoint(red)
PlaygroundKeyValueStore.current["g"] = .floatingPoint(green)
PlaygroundKeyValueStore.current["b"] = .floatingPoint(blue)
//#-end-hidden-code
/*:
 
 You've finished the playground book, [congrats!](@next)
 
 */

