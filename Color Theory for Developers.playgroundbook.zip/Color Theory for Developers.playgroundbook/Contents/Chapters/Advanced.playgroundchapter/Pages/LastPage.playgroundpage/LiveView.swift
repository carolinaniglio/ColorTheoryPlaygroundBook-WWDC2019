// by Carolina Niglio for WWDC 2019
//Page 3 - Live View

import PlaygroundSupport
import SpriteKit

let sceneView = SKView(frame: CGRect(x: 0 , y: 0, width: 1024, height: 768))
let scene = RGB(size: CGSize(width: 1024, height: 768))
scene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
scene.scaleMode = .aspectFill
scene.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
sceneView.presentScene(scene)

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
