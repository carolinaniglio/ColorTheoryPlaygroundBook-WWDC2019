// // by Carolina Niglio for WWDC 2019
// Page 4 - RGB Class

import PlaygroundSupport
import SpriteKit

public class RGB: SKScene {
    
    //Declaring Variables
    var sxNode = SKShapeNode(circleOfRadius: 120)
    var dxNode = SKShapeNode(circleOfRadius: 120)
        
    var r: CGFloat = 0
    var g: CGFloat = 0
    var b: CGFloat = 0
    
    var start: Bool?
    
    var theColor: String?
    
    var label = SKLabelNode(text: "Guess")

    public override func sceneDidLoad() {
        
        sxNode.fillColor = UIColor(red: 0, green: 0 , blue: 0, alpha: 1)

        label.position = CGPoint(x: 0, y: -200)
        label.fontColor = SKColor.black
        label.fontName = "Avenir Light"
        label.fontSize = 32.0
        label.alpha = 0
        addChild(label)

        sxNode.lineWidth = 2.0
        sxNode.position = CGPoint(x: -180, y: 0)
        addChild(sxNode)
        
        dxNode.fillColor = UIColor(red: r / 255, green: g / 255, blue: b / 255, alpha: 1)
        dxNode.lineWidth = 2.0
        dxNode.position = CGPoint(x: 180, y: 0)
        addChild(dxNode)
        
        start = true
        }
    
    //Taking the value from LiveView
    public override func update(_ currentTime: TimeInterval) {
        
    //Right node
    if let keyValue = PlaygroundKeyValueStore.current["r"],
    case .floatingPoint(let red) = keyValue {
        r = CGFloat(red)
            }
    if let keyValue = PlaygroundKeyValueStore.current["g"],
            case .floatingPoint(let green) = keyValue {
            g = CGFloat(green)
        }
    if let keyValue = PlaygroundKeyValueStore.current["b"],
            case .floatingPoint(let blue) = keyValue {
            b = CGFloat(blue)
        }
        
    dxNode.fillColor = UIColor(red: r / 255, green: g / 255, blue: b / 255, alpha: 1)

    //Left node
    if let keyValue = PlaygroundKeyValueStore.current["color"],
            case .string(let color) = keyValue {
            theColor = color
        
        switch theColor {
        case "red":
            sxNode.fillColor = .red
            start = false
        case "orange":
            sxNode.fillColor = .orange
            start = false
        case "yellow":
            sxNode.fillColor = .yellow
            start = false
        case "green":
            sxNode.fillColor = .green
            start = false
        case "cyan":
            sxNode.fillColor = .cyan
            start = false
        case "blue":
            sxNode.fillColor = .blue
            start = false
        case "magenta":
            sxNode.fillColor = .magenta
            start = false
        case "purple":
            sxNode.fillColor = .purple
            start = false
        case "gray":
            sxNode.fillColor = .gray
            start = false
        case "brown":
            sxNode.fillColor = .brown
            start = false
        case "black":
            sxNode.fillColor = .black
            start = false
        case "white":
            sxNode.fillColor = .white
            start = false
        default:
            label.text = "Guess"
        }
    }
    
 check()

}

//Checking if it is the same color
    func check () {
    if dxNode.fillColor == sxNode.fillColor && start == false {
        label.alpha = 1
        
        label.text = "Right!"
            }
    else if dxNode.fillColor != sxNode.fillColor && start == false {
        label.alpha = 1
        label.text = "Wrong"
            }
        }

}
